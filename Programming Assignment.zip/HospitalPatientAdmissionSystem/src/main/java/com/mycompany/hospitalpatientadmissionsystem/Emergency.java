
package com.mycompany.hospitalpatientadmissionsystem;

public class Emergency extends Patient{
    private String status;
    private String arrivalTime;
    private  boolean immediateSurgery;
    
    //constructor for emergency patient
       public Emergency(String patientId, String name, String lastName, String gender, String medicalCondition, int age, PatientCategory category,String status, String arrivalTime,boolean immidiateSurgery){
        super(patientId,name,lastName,gender,medicalCondition,age,category);
        this.status=status;
        this.arrivalTime=arrivalTime;
        this.immediateSurgery=immediateSurgery;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public void setImmediateSurgery(boolean immediateSurgery) {
        this.immediateSurgery = immediateSurgery;
    }

    public String getStatus() {
        return status;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public boolean isImmediateSurgery() {
        return immediateSurgery;
    }
@Override
public void displayDetails(){
    super.displayDetails();
    System.out.println("Triage level: "+status);
    System.out.println("Arrival time: "+ arrivalTime);
    System.out.println("Reguires Immediate Surgery: "+ immediateSurgery);
    
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

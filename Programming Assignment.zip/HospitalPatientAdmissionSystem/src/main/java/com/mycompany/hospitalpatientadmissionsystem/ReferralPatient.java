
package com.mycompany.hospitalpatientadmissionsystem;

public class ReferralPatient extends Patient{
        private int consultationNumber;
        private String referringDoctor;
        //constructor for referralPatient
    public ReferralPatient(int consultationNumber,String name, String lastName ,String gender,String medicalCondition,PatientCategory category,int age,String patientId,String referringDoctor) {
        super(patientId,name,lastName,gender,medicalCondition,age,category);
        this.consultationNumber = consultationNumber;
        this.referringDoctor= referringDoctor;
    }   

    public String getReferringDoctor() {
        
        return referringDoctor;
    }
    
    public void setReferringDoctor(String referringDoctor){
        this.referringDoctor= referringDoctor;
    }

    public void setConsultationNumber(int consultationNumber) {
        this.consultationNumber = consultationNumber;
    }

    public int getConsultationNumber() {
        return consultationNumber;
    }

  @Override
  public void displayDetails(){
     super.displayDetails();
     System.out.println("ConsultationNumber:"+ consultationNumber);
     System.out.println("Referring Doctor:"+ referringDoctor);
  }
  
  
  @Override
  public String toString(){
      return super.toString()+String.format(" | Consultation No: %d | Referring Doctor: %s", 
                consultationNumber, referringDoctor);
              
    }
}

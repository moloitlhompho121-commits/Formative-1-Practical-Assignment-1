
package com.mycompany.hospitalpatientadmissionsystem;

public enum PatientCategory {
    //regular,emegency,referral
    REGULAR,EMERGENCY,REFERRAL
}

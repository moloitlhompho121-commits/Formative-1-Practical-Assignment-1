
package com.mycompany.hospitalpatientadmissionsystem;
import java.util.Scanner;

public class HospitalPatientAdmissionSystem {

    public static void main(String[] args) {
        BedManagementLayout clinic =new BedManagementLayout();
       
        Scanner scan= new Scanner(System.in);
        boolean executing = true;
        
        while (executing){
        System.out.println("===========================================");
        System.out.println("Welcome to the Hospital management System!");
        System.out.println("Select an option from the list below(1-8):");
        System.out.println("1. Register New Rugular Patient:");
        System.out.println("2. Register Referral Patient:");
        System.out.println(" 3.Assign Referral Patient a Room/Bed:");
        System.out.println("4.Discharge Patient From Room:");
        System.out.println("5.Search Patient By Id");
        System.out.println("6.View Ward Layout:");
        System.out.println("7.Display All Patients");
        System.out.println("8.Delete Patient Profile:");
        System.out.println("9. Exit:");
        System.out.print("Enter choice:  ");
        
        //read user input
        int choice =scan.nextInt();
        scan.nextLine();
        
        //execution  logic
        switch(choice){
            //Register Standard patient
            case 1 -> {
                System.out.print("Enter Patient Id:");
                String id =scan.nextLine();
                System.out.print("Enter  name:");
                String name =scan.nextLine();
                System.out.print("Enter Last Name");
                String lastName=scan.nextLine();
                System.out.print("Enter Gender: ");
                String gender=scan.nextLine();
                System.out.println("Enter Age:");
                int age= scan.nextInt();
                scan.nextLine();
                System.out.print("Enter medical Condition:");
                String condition=scan.nextLine();
                scan.nextLine();
                System.out.print("Select Category(1-REGULAR, 2-REFERRAL 3-EMERGENCY):");
                int categoryChoice=scan.nextInt();
                scan.nextLine();
                //Map  numeric input choice to the correct PatientCategory enum value
                PatientCategory type=(categoryChoice ==3)? PatientCategory.EMERGENCY:
                                     (categoryChoice ==2)?PatientCategory.REFERRAL: PatientCategory.REGULAR; 
                Patient person=new Patient(id,name,lastName, gender, condition, age, type);
                clinic.registerPatient(person);
            }//end of case 1
            
            case  2 -> {
            //Registser Referred Patient
                System.out.print("Enter Patient Id:");
                String id =scan.nextLine();
                System.out.print("Enter  name:");
                String name =scan.nextLine();
                System.out.print("Enter Last Name");
                String lastName=scan.nextLine();
                System.out.print("Enter Gender: ");
                String gender=scan.nextLine();
                System.out.println("Enter Age:");
                int age= scan.nextInt();
                scan.nextLine();
                System.out.print("Enter medical Condition:");
                String condition=scan.nextLine();
                System.out.print("Rerring Doctor");
                String doctor=scan.nextLine();
                System.out.print("Enter the Consultation number:");
                int consultNum=scan.nextInt();
                scan.nextLine();
                
                
                ReferralPatient referralPatient =new ReferralPatient(consultNum,name,lastName,gender,condition,PatientCategory.REFERRAL,age,id,doctor);
                clinic.registerPatient(referralPatient);
                        
        
            }//end case 2
            case 3 ->{
                //allocate beds
                System.out.print("Enter referral Patient ID:");
                String id=scan.nextLine();
                System.out.print("Enter  bed code(e.g, R01,R04): ");
                String bedCode=scan.nextLine();
                clinic.AllocateBed(id, bedCode);
                
            
            }//end of case 3
            case 4 -> {
                //Discharge Patient
                System.out.print("enter Patient ID to Discharge: ");
                String id=scan.nextLine();
                clinic.dischargePatient(id);

            }//ending of case 4
            case 5 -> {
                //search Patient by Id
                System.out.print("Enter Patient Id: ");
                String id=scan.nextLine();
                Patient found=clinic.findPatientById(id);
                if(found != null){
                    System.out.print("\n----Patient Details------");
                    found.displayDetails();
                }//end of if statement
                else{
                    System.out.print("Patient with ID"+ id +" not found");
                    
                }//end of else
            }//end of case 5
            case 6 -> {
                //dispaly beds
                clinic.displayWardLayout();
            }//end of case 6
            case 7 -> {
                //display All patients
                System.out.println("All Patients:");
                clinic.displayAllPatients();
            }//end of case 7
            case 8 ->{
                //delete Pateint file
                System.out.print("Enter Patient ID to delete");
                String id =scan.nextLine();
                clinic.deletePatient(id);
            }//end of case 8
            case 9 -> {
                executing = false;
                System.out.print("Exiting System. Good bye!");
            }//end of case 9
            default -> System.out.print("Invalid Choice. Please select between 1 and 9.");
                
            } 
 
        }
       scan.close();
    }
}


package com.mycompany.hospitalpatientadmissionsystem;

import java.util.Locale;

public class Patient {//Parent class
    private String patientId;
    private String name;
    private String lastName;
    private String gender;
    private String medicalCondition;
    private int age;
    private PatientCategory category;

    //consttrictor
    public Patient(String patientId, String name, String lastName, String gender, String medicalCondition, int age, PatientCategory category) {
        this.patientId = patientId;
        this.name = name;
        this.lastName = lastName;
        this.gender = gender;
        this.medicalCondition = medicalCondition;
        this.age = Math.max(age,0);
        this.category = category;
    }
    
    
    //setters and getters

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setMedicalCondition(String medicalCondition) {
        this.medicalCondition = medicalCondition;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setCategory(PatientCategory category) {
        this.category = category;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public String getGender() {
        return gender;
    }

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public int getAge() {
        return age;
    }

    public PatientCategory getCategory() {
        return category;
    }
    
    public void displayDetails(){//Start display method
        System.out.println("Patient ID: "+ patientId);
        System.out.println("Fist name"+ name);
        System.out.println("Last name:"+ lastName);
        System.out.println("Age: "+age);
        System.out.println("Gender:"+ gender);
        System.out.println("Medical condition:"+ medicalCondition);
        System.out.println("Category: "+category);
     
    }
@Override
public String toString(){
   return  String.format("ID: %s | Name: %s %s | Age: %d | Gender: %s | Condition: %s | Category: %s",
                patientId, name, lastName, age, gender, medicalCondition, category);


}

}


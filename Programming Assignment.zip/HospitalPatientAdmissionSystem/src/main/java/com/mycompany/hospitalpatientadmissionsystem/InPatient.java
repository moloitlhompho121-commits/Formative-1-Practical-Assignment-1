
package com.mycompany.hospitalpatientadmissionsystem;


public class InPatient extends Patient {
    private int wardNumber;
    private int bedNumber;

    //constructor for the inpatient class
    public InPatient(int wardNumber, int bedNumber, String patientId, String name, String lastName, String gender, String medicalCondition, int age, PatientCategory category) {
        super(patientId, name, lastName, gender, medicalCondition, age, category);
        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

  //getters and setters

    public void setWardNumber(int wardNumber) {
        this.wardNumber = wardNumber;
    }

    public void setBedNumber(int bedNumber) {
        this.bedNumber = bedNumber;
    }
    
    
    public int getWardNumber() {
        return wardNumber;
    }

    public int getBedNumber() {
        return bedNumber;
    }
@Override
public void displayDetails(){
    super.displayDetails();
    System.out.println("Ward Number:"+wardNumber);
    System.out.println("Bed Number:"+ bedNumber);


}
@Override
public String toString(){
    return super.toString() + String.format(" | Ward: %d | Bed: %d", wardNumber, bedNumber);
}
    
    
    
    
    
    
    
    
    
    
    
    
    
}

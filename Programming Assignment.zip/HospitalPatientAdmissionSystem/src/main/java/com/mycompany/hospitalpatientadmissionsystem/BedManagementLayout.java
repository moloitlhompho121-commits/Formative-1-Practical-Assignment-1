
package com.mycompany.hospitalpatientadmissionsystem;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Objects;
public class BedManagementLayout {
    Scanner scan=new Scanner(System.in);
    String[][] rooms= new String [4][5];
    String[][] occupied =new String [4][5];
    boolean[][]roomOccupied;
    //Array list to store patient details
    ArrayList<Patient> patients;
    private String[] roomPatientId;

   
  
    
    //public ClinicManagementLayout constructor not to contain any parameter
    public BedManagementLayout(){
        patients = new ArrayList<Patient>();
        roomPatientId = new String[20];//total rooms
        roomOccupied = new boolean[4][5];
        initializeRooms();
        
    }
    
    
    
    //this method initializes the room codes
    public void initializeRooms(){
        int roomNumber =1;
        for(int row =0;row< 4;row++){
           for(int col =0;col< 5;col++){
               if(roomNumber < 10){
                  rooms[row][col] = "R0"+roomNumber; 
               
               }//end of if
               else{
               rooms[row][col]="R"+roomNumber;
               }//end of else
               roomOccupied[row][col]= false;//terminates the for loop
               roomNumber++;
           }
        }
    
    }//end of method
    
    //map room code for 20 rooms
   public int getRoomIndex(String roomCode){
        for(int row =0;row< 4;row++){
           for(int col =0;col< 5;col++){
               if(Objects.equals(rooms[row][col],roomCode)){
                   return(row * 5)+col;
               }
           }
        }
       return-1;//room not found
   
   } //end of room code method
   
   
   //Patient registration validation method
   public boolean registerPatient(Patient patient){
       if(findPatientById(patient.getPatientId()) != null){
           System.out.println("validation Error: Patient"+patient.getPatientId()+" already exits!");
           return false;
       }//endof if Statements
       patients.add(patient);
       System.out.println("Patient "+ patient.getName()+" registered successfully");
       return true;
   }
    //end of method
   
   
     //search patient by id
    public Patient findPatientById(String patientId){
        if(patientId ==null);
        String cleanId=patientId.trim();
       for(int i=0;i< patients.size();i++ ){
           Patient p=patients.get(i);
           if(p.getPatientId()!= null && p.getPatientId().trim().equalsIgnoreCase(cleanId)){
            return p;
         
           }
       }
       return null;//if the patient is not found
        
    }//end of search method
       
   
   
   
   

   //register  new patient
 public void registerReferralPatient(Patient patient){
     Patient existing = findPatientById(patient.getPatientId());
     if(existing != null){System.out.println("Patient Id already exists");
      return;
      }
      patients.add(patient);
      System.out.println(" Referral Pateint is added succesfully");
    
       }//end of method
 //update ixixsting Patient details
 public boolean updatePatientDetails(String patientId,String newName,String newLastName,String newGender,String newCondition,int newAge){
     Patient patient =findPatientById(patientId);
     if(patient == null){
         System.out.println("Validation error: Patient with ID "+patientId+" not found.");
         return false; 
     }//end of if
     patient.setName(newName);
     patient.setLastName(newLastName);
     patient.setGender(newGender);
     patient.setMedicalCondition(newCondition);
     patient.setAge(newAge);
     System.out.println("Success: Patient details updated fo ID "+patientId+" .");
     return true;
     
 }
 
 
 
 
 //Check if Referalpatient is already allocated a bed
 public boolean isReferralPatientAlreadyAssigned(String patientId){
     for(int i=0;i< roomPatientId.length;i++){
         if(roomPatientId[i] != null && roomPatientId[i].equalsIgnoreCase(patientId)){
             return true;
         }//end of if statement
     }//end of for loop
     System.out.println("Error. Patient is already assigned a bed!");
     return false;
 }//end of method
 
 //validate referralpatients
 

    
    //Allocate a Inpatient  to a sppecific bed
    public boolean AllocateBed(String patientId, String roomCode){
    Patient p =findPatientById(patientId);
    if(p ==null){
     System.out.print("error: Patient not found");
     return false;
    }
    //validation for referral patients only
    if(!(p instanceof ReferralPatient)&&p.getCategory()!= PatientCategory.REFERRAL){
        System.out.println("Access denied: only Inpatient can have access to beds");
        return false;
    
    }
    if(isReferralPatientAlreadyAssigned(patientId)){
        System.out.println("Validation error: Patient already has an assigned bed!");
        return false;
    
    }
    int bed =getRoomIndex(roomCode);
    if (bed == -1){
      System.out.println("Error: RoomCode"+roomCode+"Does not exist");
    }
    int row = bed/5;
    int col = bed%5;
    
    if(!roomOccupied[row][col]){
        roomOccupied[row][col]=true;
        roomPatientId[bed]=p.getPatientId();
        System.out.println("Inpatient "+p.getName()+"Allocated bed "+roomCode+" successfully.");
        return true;
    
    }
    
      return false; 
    }
    //Bed allocation validation
    public boolean isAllocatedbed(String patientId,String bedCode){
        //check if patient already exists
        Patient patient = findPatientById(patientId);
        if(patient == null){
            System.out.println("VAlidation error: Patient ID "+patientId+" is not registered.");
            return false;
        }//end of if statement
        //check if patient is a referral
        if(patient.getCategory()!= PatientCategory.REFERRAL){
            System.out.println("Validation error: Only Referral Patients can be allocated beds!");
            return false;
        }//end of is Statement
        //check if  patient is already  allocated a   bed
        if(isReferralPatientAlreadyAssigned(patientId)){
            System.out.println("Validation error: Patient "+patientId+" already has an assigned bed!");
            return false;
        }//end of if statement
        //chack valid bed code
        int index=getRoomIndex(bedCode);
        if(index == -1){
            System.out.println("Validation error: bed code "+bedCode+" does not exist!");
            return false;
        
        }//end if if statement
        int row =index /5;
        int col =index %5;
        //check if bed is aleady occupied
        if(roomOccupied[row][col]){
            System.out.println("Validation error: Bed "+bedCode+" is already occiped by patient "+roomPatientId[index]+"!");
            return false;
        }//end of if statement
        //assign bed if all requirements are meet
        if(!roomOccupied[row][col]){
        roomOccupied[row][col]=true;
        roomPatientId[index]= patientId;
        System.out.println("Success: Bed "+bedCode+" assigned to patient "+patientId+"." );
        return true;
        }
      return false;
    }//end of method
    
     
    //discharge patient from bed
    public boolean dischargePatient(String patientId){
        for(int i=0;i<roomPatientId.length;i++){
            if(roomPatientId[i] !=null &&roomPatientId[i].equalsIgnoreCase(patientId)){
                int row= i / 5;
                int col= i % 5;
                roomOccupied[row][col]= false;
                roomPatientId[i] =null;
                System.out.println("Success Patient "+patientId+" discharged from bed "+rooms[row][col]+".");
                return true;
                
            }
        
        }
       System.out.println(" VAlidation Error: Patient "+patientId+" is not assigned any bed.");
       return false;
          
    }
//deleting  patient file method
    public boolean deletePatient(String patientId){
        Patient p = findPatientById(patientId);
        if(p !=  null){
            dischargePatient(patientId);
            patients.remove(p);
            System.out.println("Patient removed from the system");
            return true;
        }
        System.out.println("Patient not found");
        return false;
    }
    //display ward layout
    public void displayWardLayout(){
        System.out.println("\n--------INPATIENT WARD LAYOUT---------");
        for(int row=0;row < 4;row++){
            for(int col =0;col<5;col++){
                String status= roomOccupied[row][col]?"[OCCUPIED]":"[VACANT]";
                System.out.print(rooms[row][col]+" "+status+" ");                
            }
            System.out.println();
        }        
    }
    //display all patients
    public void displayAllPatients(){
        if(patients.isEmpty()){
            System.out.println("No patients currently registered");
            return;
        }
          System.out.println("\n---All Registered Patients---");
          for(Patient p: patients){
              p.displayDetails();
              System.out.println("-----------------------------");
              
          }
    } 
    
}//end of ClinicmaagementLayout







